﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProjectMVCSem2;

namespace ProjectMVCSem2.Controllers
{
    
    [Authorize]
    public class cityController : Controller
    {
        private TheTourEntities1 db = new TheTourEntities1();

        // GET: city
        public ActionResult Index()
        {
            var tbl_city = db.tbl_city.Include(t => t.tbl_state);
            return View(tbl_city.ToList());
        }

        // GET: city/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_city tbl_city = db.tbl_city.Find(id);
            if (tbl_city == null)
            {
                return HttpNotFound();
            }
            return View(tbl_city);
        }

        // GET: city/Create
        public ActionResult Create()
        {
            ViewBag.state_id = new SelectList(db.tbl_state, "state_id", "state_name");
            return View();
        }

        // POST: city/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "city_id,city_name,state_id")] tbl_city tbl_city)
        {
            if (ModelState.IsValid)
            {
                tbl_city.createDate = DateTime.Now;
                tbl_city.updateDate = DateTime.Now;
                db.tbl_city.Add(tbl_city);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.state_id = new SelectList(db.tbl_state, "state_id", "state_name", tbl_city.state_id);
            return View(tbl_city);
        }

        // GET: city/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_city tbl_city = db.tbl_city.Find(id);
            if (tbl_city == null)
            {
                return HttpNotFound();
            }
            ViewBag.state_id = new SelectList(db.tbl_state, "state_id", "state_name", tbl_city.state_id);
            return View(tbl_city);
        }

        // POST: city/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "city_id,city_name,state_id,createDate")] tbl_city tbl_city)
        {
            if (ModelState.IsValid)
            {
                tbl_city.updateDate = DateTime.Now;
                db.Entry(tbl_city).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.state_id = new SelectList(db.tbl_state, "state_id", "state_name", tbl_city.state_id);
            return View(tbl_city);
        }

        // GET: city/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_city tbl_city = db.tbl_city.Find(id);
            if (tbl_city == null)
            {
                return HttpNotFound();
            }
            return View(tbl_city);
        }

        // POST: city/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_city tbl_city = db.tbl_city.Find(id);
            db.tbl_city.Remove(tbl_city);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
