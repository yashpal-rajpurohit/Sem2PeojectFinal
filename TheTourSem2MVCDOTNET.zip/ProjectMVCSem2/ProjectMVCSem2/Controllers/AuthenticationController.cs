﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.Mvc;
//using System.Web.Security;
//using ProjectMVCSem2.Models;

//namespace ProjectMVCSem2.Controllers
//{
//    public class AuthenticationController : Controller
//    {
//        TheTourEntities1 tourLogin = new TheTourEntities1();
//        // GET: Authentication
//        public ActionResult Login()
//        {
//            return View();
//        }
//        [HttpPost]
//        public ActionResult Login( UserLogin userlogin)
//        {
//            if (ModelState.IsValid)
//            {
//                int userid = (from u in tourLogin.tbl_user
//                             where u.user_email == userlogin.user_email
//                             where u.user_password == userlogin.user_password
//                             select u.user_id).FirstOrDefault();
//                FormsAuthentication.SetAuthCookie(userid.ToString(), userlogin.RememberMe);

//                return RedirectToAction("Index", "city");
//            }
//            ViewBag.NotValidUser = "userEmail or Password is Not Valid ";



//            return View();
//        }
        
//        public ActionResult Logout()
//        {
//            FormsAuthentication.SignOut();
//            return RedirectToAction("Login", "Authentication");
//        }
//    }
//}