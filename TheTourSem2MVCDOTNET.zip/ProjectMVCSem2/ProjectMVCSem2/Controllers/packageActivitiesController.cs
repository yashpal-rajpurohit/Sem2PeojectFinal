﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProjectMVCSem2;

namespace ProjectMVCSem2.Controllers
{
    public class packageActivitiesController : Controller
    {
        private TheTourEntities1 db = new TheTourEntities1();

        // GET: packageActivities
        public ActionResult Index()
        {
            var tbl_packageActivities = db.tbl_packageActivities.Include(t => t.tbl_Activity).Include(t => t.tbl_package);
            return View(tbl_packageActivities.ToList());
        }

        // GET: packageActivities/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_packageActivities tbl_packageActivities = db.tbl_packageActivities.Find(id);
            if (tbl_packageActivities == null)
            {
                return HttpNotFound();
            }
            return View(tbl_packageActivities);
        }

        // GET: packageActivities/Create
        public ActionResult Create()
        {
            ViewBag.activity_id = new SelectList(db.tbl_Activity, "activity_id", "activity_name");
            ViewBag.package_id = new SelectList(db.tbl_package, "package_id", "package_name");
            return View();
        }

        // POST: packageActivities/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "packageActivities_id,package_id,activity_id,createDate,updateDate,isActive,isDelete")] tbl_packageActivities tbl_packageActivities)
        {
            if (ModelState.IsValid)
            {
                db.tbl_packageActivities.Add(tbl_packageActivities);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.activity_id = new SelectList(db.tbl_Activity, "activity_id", "activity_name", tbl_packageActivities.activity_id);
            ViewBag.package_id = new SelectList(db.tbl_package, "package_id", "package_name", tbl_packageActivities.package_id);
            return View(tbl_packageActivities);
        }

        // GET: packageActivities/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_packageActivities tbl_packageActivities = db.tbl_packageActivities.Find(id);
            if (tbl_packageActivities == null)
            {
                return HttpNotFound();
            }
            ViewBag.activity_id = new SelectList(db.tbl_Activity, "activity_id", "activity_name", tbl_packageActivities.activity_id);
            ViewBag.package_id = new SelectList(db.tbl_package, "package_id", "package_name", tbl_packageActivities.package_id);
            return View(tbl_packageActivities);
        }

        // POST: packageActivities/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "packageActivities_id,package_id,activity_id,createDate,updateDate,isActive,isDelete")] tbl_packageActivities tbl_packageActivities)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_packageActivities).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.activity_id = new SelectList(db.tbl_Activity, "activity_id", "activity_name", tbl_packageActivities.activity_id);
            ViewBag.package_id = new SelectList(db.tbl_package, "package_id", "package_name", tbl_packageActivities.package_id);
            return View(tbl_packageActivities);
        }

        // GET: packageActivities/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_packageActivities tbl_packageActivities = db.tbl_packageActivities.Find(id);
            if (tbl_packageActivities == null)
            {
                return HttpNotFound();
            }
            return View(tbl_packageActivities);
        }

        // POST: packageActivities/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_packageActivities tbl_packageActivities = db.tbl_packageActivities.Find(id);
            db.tbl_packageActivities.Remove(tbl_packageActivities);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
