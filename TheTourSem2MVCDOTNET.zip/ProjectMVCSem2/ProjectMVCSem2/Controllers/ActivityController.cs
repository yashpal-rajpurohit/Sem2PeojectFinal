﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProjectMVCSem2;

namespace ProjectMVCSem2.Controllers
{
    [Authorize]
    public class ActivityController : Controller
    {
        private TheTourEntities1 db = new TheTourEntities1();

        // GET: Activity
        public ActionResult Index()
        {
            var tbl_Activity = db.tbl_Activity.Include(t => t.tbl_activityType);
            return View(tbl_Activity.ToList());
        }

        // GET: Activity/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_Activity tbl_Activity = db.tbl_Activity.Find(id);
            if (tbl_Activity == null)
            {
                return HttpNotFound();
            }
            return View(tbl_Activity);
        }

        // GET: Activity/Create
        public ActionResult Create()
        {
            ViewBag.activity_type = new SelectList(db.tbl_activityType, "activityType_id", "activityType_name");
            return View();
        }

        // POST: Activity/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "activity_id,activity_name,activity_timing,activity_cost,activity_type")] tbl_Activity tbl_Activity)
        {
            if (ModelState.IsValid)
            {

                tbl_Activity.createDate = DateTime.Now;
                tbl_Activity.updateDate = DateTime.Now;
              
                db.tbl_Activity.Add(tbl_Activity);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.activity_type = new SelectList(db.tbl_activityType, "activityType_id", "activityType_name", tbl_Activity.activity_type);
            return View(tbl_Activity);
        }

        // GET: Activity/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_Activity tbl_Activity = db.tbl_Activity.Find(id);
            if (tbl_Activity == null)
            {
                return HttpNotFound();
            }
            ViewBag.activity_type = new SelectList(db.tbl_activityType, "activityType_id", "activityType_name", tbl_Activity.activity_type);
            return View(tbl_Activity);
        }

        // POST: Activity/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "activity_id,activity_name,activity_timing,activity_cost,activity_type,createDate")] tbl_Activity tbl_Activity)
        {
            if (ModelState.IsValid)
            {
                tbl_Activity.updateDate = DateTime.Now;

                db.Entry(tbl_Activity).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.activity_type = new SelectList(db.tbl_activityType, "activityType_id", "activityType_name", tbl_Activity.activity_type);
            return View(tbl_Activity);
        }

        // GET: Activity/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_Activity tbl_Activity = db.tbl_Activity.Find(id);
            if (tbl_Activity == null)
            {
                return HttpNotFound();
            }
            return View(tbl_Activity);
        }

        // POST: Activity/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_Activity tbl_Activity = db.tbl_Activity.Find(id);
            db.tbl_Activity.Remove(tbl_Activity);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
