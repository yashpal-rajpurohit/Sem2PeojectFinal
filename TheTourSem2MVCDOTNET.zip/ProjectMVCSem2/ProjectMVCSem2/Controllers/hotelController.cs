﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProjectMVCSem2;

namespace ProjectMVCSem2.Controllers
{
    [Authorize]
    public class hotelController : Controller
    {
        private TheTourEntities1 db = new TheTourEntities1();

        // GET: hotel
        public ActionResult Index()
        {
            var tbl_hotel = db.tbl_hotel.Include(t => t.tbl_city).Include(t => t.tbl_foodTimeDetails);
            return View(tbl_hotel.ToList());
        }

        // GET: hotel/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_hotel tbl_hotel = db.tbl_hotel.Find(id);
            if (tbl_hotel == null)
            {
                return HttpNotFound();
            }
            return View(tbl_hotel);
        }

        // GET: hotel/Create
        public ActionResult Create()
        {
            ViewBag.city_id = new SelectList(db.tbl_city, "city_id", "city_name");
            ViewBag.foodTime_id = new SelectList(db.tbl_foodTimeDetails, "foodTime_id", "foodTime__name");
            return View();
        }

        // POST: hotel/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "hotel_id,hotel_name,city_id,foodTime_id,hotel_Cost")] tbl_hotel tbl_hotel)
        {
            if (ModelState.IsValid)
            {
                tbl_hotel.createDate = DateTime.Now;
                tbl_hotel.updateDate = DateTime.Now;
               
                db.tbl_hotel.Add(tbl_hotel);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_hotel.city_id);
            ViewBag.foodTime_id = new SelectList(db.tbl_foodTimeDetails, "foodTime_id", "foodTime__name", tbl_hotel.foodTime_id);
            return View(tbl_hotel);
        }

        // GET: hotel/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_hotel tbl_hotel = db.tbl_hotel.Find(id);
            if (tbl_hotel == null)
            {
                return HttpNotFound();
            }
            ViewBag.city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_hotel.city_id);
            ViewBag.foodTime_id = new SelectList(db.tbl_foodTimeDetails, "foodTime_id", "foodTime__name", tbl_hotel.foodTime_id);
            return View(tbl_hotel);
        }

        // POST: hotel/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "hotel_id,hotel_name,city_id,foodTime_id,hotel_Cost,createDate")] tbl_hotel tbl_hotel)
        {
            if (ModelState.IsValid)
            {
                tbl_hotel.updateDate = DateTime.Now;
               
                db.Entry(tbl_hotel).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_hotel.city_id);
            ViewBag.foodTime_id = new SelectList(db.tbl_foodTimeDetails, "foodTime_id", "foodTime__name", tbl_hotel.foodTime_id);
            return View(tbl_hotel);
        }

        // GET: hotel/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_hotel tbl_hotel = db.tbl_hotel.Find(id);
            if (tbl_hotel == null)
            {
                return HttpNotFound();
            }
            return View(tbl_hotel);
        }

        // POST: hotel/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_hotel tbl_hotel = db.tbl_hotel.Find(id);
            db.tbl_hotel.Remove(tbl_hotel);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
