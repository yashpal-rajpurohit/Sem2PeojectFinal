﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProjectMVCSem2;

namespace ProjectMVCSem2.Controllers
{
    [Authorize]
    public class activityTypeController : Controller
    {

        private TheTourEntities1 db = new TheTourEntities1();

        // GET: activityType
        public ActionResult Index()
        {
            return View(db.tbl_activityType.ToList());
        }

        // GET: activityType/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_activityType tbl_activityType = db.tbl_activityType.Find(id);
            if (tbl_activityType == null)
            {
                return HttpNotFound();
            }
            return View(tbl_activityType);
        }

        // GET: activityType/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: activityType/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "activityType_id,activityType_name")] tbl_activityType tbl_activityType)
        {
            if (ModelState.IsValid)
            {
                tbl_activityType.createDate = DateTime.Now;
                tbl_activityType.updateDate = DateTime.Now;
               
                db.tbl_activityType.Add(tbl_activityType);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tbl_activityType);
        }

        // GET: activityType/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_activityType tbl_activityType = db.tbl_activityType.Find(id);
            if (tbl_activityType == null)
            {
                return HttpNotFound();
            }
            return View(tbl_activityType);
        }

        // POST: activityType/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "activityType_id,activityType_name,createDate")] tbl_activityType tbl_activityType)
        {
            if (ModelState.IsValid)
            {
                tbl_activityType.updateDate = DateTime.Now;
              
                db.Entry(tbl_activityType).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tbl_activityType);
        }

        // GET: activityType/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_activityType tbl_activityType = db.tbl_activityType.Find(id);
            if (tbl_activityType == null)
            {
                return HttpNotFound();
            }
            return View(tbl_activityType);
        }

        // POST: activityType/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_activityType tbl_activityType = db.tbl_activityType.Find(id);
            db.tbl_activityType.Remove(tbl_activityType);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
