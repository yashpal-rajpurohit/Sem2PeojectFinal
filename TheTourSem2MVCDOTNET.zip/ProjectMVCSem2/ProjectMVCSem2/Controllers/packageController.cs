﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProjectMVCSem2;
using ProjectMVCSem2.Models;

namespace ProjectMVCSem2.Controllers
{

    [Authorize]
    public class packageController : Controller
    {
        private TheTourEntities1 db = new TheTourEntities1();

        // GET: package
        public ActionResult Index()
        {
            var tbl_package = db.tbl_package.Include(t => t.tbl_city).Include(t => t.tbl_guide).Include(t => t.tbl_hotel);
            return View(tbl_package.ToList());
        }

        // GET: package/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_package tbl_package = db.tbl_package.Find(id);
            if (tbl_package == null)
            {
                return HttpNotFound();
            }
            string path =tbl_package.package_image;
            string subpath = path.Substring(path.IndexOf("\\images"));
            ViewBag.subpath = subpath;
            return View(tbl_package);
        }

        // GET: package/Create
        public ActionResult Create()
        {
            ViewBag.package_city_id = new SelectList(db.tbl_city, "city_id", "city_name");
            ViewBag.package_guide_id = new SelectList(db.tbl_guide, "guide_id", "guide_name");
            ViewBag.package_hotel_id = new SelectList(db.tbl_hotel, "hotel_id", "hotel_name");
            ViewBag.package_activities_id = new SelectList(db.tbl_Activity, "activity_id", "activity_name");
            //ViewBag.user_id = new SelectList(db.tbl_user, "user_id", "user_fname");
            return View();
        }

        // POST: package/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(packageModel package,HttpPostedFileBase package_image)
        {
            //int updatedid = 0;
            tbl_hotel hotel = db.tbl_hotel.Find(package.package_hotel_id);
            decimal hotelcost = hotel.hotel_Cost;


            tbl_guide guide = db.tbl_guide.Find(package.package_guide_id);
            decimal guidecost = guide.guide_fees;

            decimal cost = (package.package_noOfDays * hotelcost) +( package.package_noOfDays * guidecost);

            tbl_package my = new tbl_package() ;
            Random rnumber = new Random();
            tbl_package demo = new tbl_package();
            string path = Server.MapPath("~/images/" + rnumber.Next() + package_image.FileName);

            tbl_package insertpackage = new tbl_package();
            tbl_packageActivities packageactivites = new tbl_packageActivities();
            decimal totalcost = cost;
            if (ModelState.IsValid)
            {
                insertpackage.package_name = package.package_name;
                insertpackage.package_image = path;//package.package_image;
                insertpackage.package_detail = package.package_detail;
                insertpackage.package_city_id = package.package_city_id;
                insertpackage.package_guide_id = package.package_guide_id;
                insertpackage.package_hotel_id = package.package_hotel_id;
                insertpackage.package_noOfDays = package.package_noOfDays;
                insertpackage.package_noOfNights = package.package_noOfNights;
                insertpackage.package_totalCost = cost;
                insertpackage.user_id = int.Parse( User.Identity.Name);
                insertpackage.package_status = true;
                insertpackage.createDate = DateTime.Now;
                insertpackage.updateDate = DateTime.Now;
               
                db.tbl_package.Add(insertpackage);
                db.SaveChanges();
                package_image.SaveAs(path);

                foreach (var activityid in package.package_activities_id)
                {
                    packageactivites.package_id = insertpackage.package_id;
                    packageactivites.activity_id = activityid;
                    packageactivites.createDate = DateTime.Now;
                    packageactivites.updateDate = DateTime.Now;

                    db.tbl_packageActivities.Add(packageactivites);
                    
                    db.SaveChanges();
                    totalcost+= db.tbl_Activity.Find(activityid).activity_cost;
                     
                }
                my = db.tbl_package.Find(insertpackage.package_id);
                my.package_totalCost = totalcost;
                db.tbl_package.Attach(my);
                db.Entry(my).Property(x => x.package_totalCost).IsModified = true;
                db.SaveChanges();
            
                return RedirectToAction("Index");
            }

        //    ViewBag.package_city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_package.package_city_id);
        //    ViewBag.package_guide_id = new SelectList(db.tbl_guide, "guide_id", "guide_name", tbl_package.package_guide_id);
        //    ViewBag.package_hotel_id = new SelectList(db.tbl_hotel, "hotel_id", "hotel_name", tbl_package.package_hotel_id);
        //    ViewBag.user_id = new SelectList(db.tbl_user, "user_id", "user_fname", tbl_package.user_id);
            return View(package);
        }

        // GET: package/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_package tbl_package = db.tbl_package.Find(id);
            if (tbl_package == null)
            {
                return HttpNotFound();
            }
            ViewBag.package_city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_package.package_city_id);
            ViewBag.package_guide_id = new SelectList(db.tbl_guide, "guide_id", "guide_name", tbl_package.package_guide_id);
            ViewBag.package_hotel_id = new SelectList(db.tbl_hotel, "hotel_id", "hotel_name", tbl_package.package_hotel_id);
            ViewBag.user_id = new SelectList(db.tbl_user, "user_id", "user_fname", tbl_package.user_id);
            return View(tbl_package);
        }

        // POST: package/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "package_id,package_name,package_detail,package_image,package_noOfDays,package_noOfNights,package_hotel_id,package_guide_id,package_city_id,package_totalCost,package_status,user_id,createDate,updateDate,isActive,isDelete")] tbl_package tbl_package)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_package).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.package_city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_package.package_city_id);
            ViewBag.package_guide_id = new SelectList(db.tbl_guide, "guide_id", "guide_name", tbl_package.package_guide_id);
            ViewBag.package_hotel_id = new SelectList(db.tbl_hotel, "hotel_id", "hotel_name", tbl_package.package_hotel_id);
            ViewBag.user_id = new SelectList(db.tbl_user, "user_id", "user_fname", tbl_package.user_id);
            return View(tbl_package);
        }

        // GET: package/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_package tbl_package = db.tbl_package.Find(id);
            if (tbl_package == null)
            {
                return HttpNotFound();
            }
            string path = tbl_package.package_image;
            string subpath = path.Substring(path.IndexOf("\\images"));
            ViewBag.subpath = subpath;

            return View(tbl_package);
        }

        // POST: package/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
           var packactivities = db.tbl_packageActivities.Where(pack => pack.package_id == id);

            foreach (var p in packactivities)
            {
                db.tbl_packageActivities.Remove(p);
            }
            db.SaveChanges();
            
            tbl_package tbl_package = db.tbl_package.Find(id);
            db.tbl_package.Remove(tbl_package);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
