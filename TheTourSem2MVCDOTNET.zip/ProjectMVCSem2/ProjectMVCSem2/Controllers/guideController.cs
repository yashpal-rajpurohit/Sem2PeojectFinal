﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProjectMVCSem2;

namespace ProjectMVCSem2.Controllers
{
    [Authorize]
    public class guideController : Controller
    {
        private TheTourEntities1 db = new TheTourEntities1();

        // GET: guide
        public ActionResult Index()
        {
            var tbl_guide = db.tbl_guide.Include(t => t.tbl_city);
            return View(tbl_guide.ToList());
        }

        // GET: guide/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_guide tbl_guide = db.tbl_guide.Find(id);
            if (tbl_guide == null)
            {
                return HttpNotFound();
            }
            return View(tbl_guide);
        }

        // GET: guide/Create
        public ActionResult Create()
        {
            ViewBag.guide_city_id = new SelectList(db.tbl_city, "city_id", "city_name");
            return View();
        }

        // POST: guide/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "guide_id,guide_name,guide_gender,guide_city_id,guide_contact,guide_fees,guide_city_id")] tbl_guide tbl_guide)
        {
            if (ModelState.IsValid)
            {
                if (tbl_guide.guide_gender == "Male")
                    tbl_guide.guide_gender = "M";
                else if (tbl_guide.guide_gender == "Female")
                    tbl_guide.guide_gender = "F";
                else
                    tbl_guide.guide_gender = "O";
                tbl_guide.createDate = DateTime.Now;
                tbl_guide.updateDate = DateTime.Now;
               tbl_guide.guide_status = true;

                db.tbl_guide.Add(tbl_guide);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.guide_city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_guide.guide_city_id);
            return View(tbl_guide);
        }

        // GET: guide/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_guide tbl_guide = db.tbl_guide.Find(id);
            if (tbl_guide == null)
            {
                return HttpNotFound();
            }
            ViewBag.guide_city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_guide.guide_city_id);
            return View(tbl_guide);
        }

        // POST: guide/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "guide_id,guide_name,guide_gender,guide_city_id,guide_contact,guide_fees,createDate")] tbl_guide tbl_guide)
        {
            if (ModelState.IsValid)
            {
                if (tbl_guide.guide_gender == "Male")
                    tbl_guide.guide_gender = "M";
                else if (tbl_guide.guide_gender == "Female")
                    tbl_guide.guide_gender = "F";
                else
                    tbl_guide.guide_gender = "O";

                tbl_guide.updateDate = DateTime.Now;
                tbl_guide.guide_status = true;

                db.Entry(tbl_guide).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.guide_city_id = new SelectList(db.tbl_city, "city_id", "city_name", tbl_guide.guide_city_id);
            return View(tbl_guide);
        }

        // GET: guide/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_guide tbl_guide = db.tbl_guide.Find(id);
            if (tbl_guide == null)
            {
                return HttpNotFound();
            }
            return View(tbl_guide);
        }

        // POST: guide/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_guide tbl_guide = db.tbl_guide.Find(id);
            db.tbl_guide.Remove(tbl_guide);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
