﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using ProjectMVCSem2.Models;


namespace ProjectMVCSem2.Controllers
{
    public class DashBoardController : Controller
    {
        private TheTourEntities1 db = new TheTourEntities1();

        // GET: DashBoard
        public ActionResult dashboard()
        {
            return View();
        }

        public ActionResult package()
        {
            var tbl_package = db.tbl_package.Include(t => t.tbl_city).Include(t => t.tbl_guide).Include(t => t.tbl_hotel);

            return View(tbl_package.ToList());
        }
        [HttpPost]
        public ActionResult packagebook(int package_id)
        {
            tbl_package tbl_package = db.tbl_package.Find(package_id);

            return View(tbl_package);
        }

        [HttpPost]
        public ActionResult NewPackage(int package_id,int user_id,DateTime Package_dateFrom, int package_noOfDays)
        {
            tbl_userPackage userpack = new tbl_userPackage();
            userpack.package_id = package_id;
            userpack.user_id = user_id;
            userpack.Package_dateFrom = Package_dateFrom;
           userpack.Package_dateTo =Package_dateFrom.AddDays(package_noOfDays);

            userpack.updateDate = DateTime.Now;
            userpack.createDate = DateTime.Now;

            db.tbl_userPackage.Add(userpack);
            db.SaveChanges();
            ViewBag.bookPackageMessage = "Package Booked We will contact on your email regarding it thank you!";
            return View("package");
        }

        public ActionResult packageSearch(string searchterm)
        {

            return View();
        }

    }

}