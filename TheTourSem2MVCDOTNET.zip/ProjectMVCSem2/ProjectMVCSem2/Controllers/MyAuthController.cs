﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using ProjectMVCSem2.Models;

namespace ProjectMVCSem2.Controllers
{
    public class MyAuthController : Controller
    {
        // GET: MyAuth
        TheTourEntities1 tourLogin = new TheTourEntities1();

        public ActionResult LoginOriginal()
        {
            return View();
        }
        [HttpPost]
        public ActionResult LoginOriginal(UserLogin userlogin)
        {
            if (ModelState.IsValid)
            {
                var user = (from u in tourLogin.tbl_user
                              where u.user_email == userlogin.user_email
                              where u.user_password == userlogin.user_password
                              select u).FirstOrDefault();

                FormsAuthentication.SetAuthCookie(user.user_id.ToString(),false);
                if (user.usertype == 1)
                    return RedirectToAction("Index", "city");
                else if (user.usertype == 2)
                    return RedirectToAction("dashboard", "Dashboard");
            }
            ViewBag.NotValidUser = "userEmail or Password is Not Valid ";



            return View();
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("LoginOriginal", "MyAuth");
        }

        [HttpGet]
        public ActionResult registration()
        {
            ViewBag.user_city_id = new SelectList(tourLogin.tbl_city, "city_id", "city_name");
            return View();
        }

        [HttpPost]
        public ActionResult registration(tbl_user user)
        {
            user.createDate = DateTime.Today;
            user.updateDate = DateTime.Today;
            user.usertype = 2;
            if (user.user_gender == "male")
            {
                user.user_gender = "M";
            }
            else {

                user.user_gender = "F";
            }
            tourLogin.tbl_user.Add(user);
            tourLogin.SaveChanges();
            return RedirectToAction("LoginOriginal");

        }
    }
}