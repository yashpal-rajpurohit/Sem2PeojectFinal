﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2
{
    public class tbl_hotelValidation
    {
        [Required(ErrorMessage ="Hotel Name cannot be blank")]
        public string hotel_name { get; set; }
       

    }

    [MetadataType(typeof(tbl_hotelValidation))]
    public partial class tbl_hotel
    {

    }

}