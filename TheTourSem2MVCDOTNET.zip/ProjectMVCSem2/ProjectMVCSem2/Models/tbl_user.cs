﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2
{
    public partial class tbl_userValidation
    {
        [Required(ErrorMessage ="FirstName cannot be blank")]
        public string user_fname { get; set; }

        [Required(ErrorMessage = "FirstLast cannot be blank")]
        public string user_lname { get; set; }

        [Required(ErrorMessage = "DOB cannot be blank")]
        public Nullable<System.DateTime> user_DOB { get; set; }
        public string user_gender { get; set; }
        public Nullable<int> user_city_id { get; set; }
        [Required(ErrorMessage ="password cannot be blank")]
        public string user_password { get; set; }
        [Required(ErrorMessage = "mobile number cannot be blank")]

        public string user_mobile { get; set; }
        [Required(ErrorMessage = "email cannot be blank")]

        public string user_email { get; set; }

    }
    [MetadataType(typeof(tbl_userValidation))]
    // Note the partial keyword
    public partial class tbl_user
    {
    }
}