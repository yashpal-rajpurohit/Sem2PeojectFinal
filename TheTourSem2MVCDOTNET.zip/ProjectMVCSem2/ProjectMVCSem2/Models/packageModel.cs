﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2.Models
{
    public class packageModel
    {
        public string package_name { get; set; }
        public string package_detail { get; set; }
        //       
        public string package_image { get; set; }
        public int package_noOfDays { get; set; }
        public int package_noOfNights { get; set; }
        public int package_hotel_id { get; set; }
        public int package_guide_id { get; set; }
        public int package_city_id { get; set; }

        public int[] package_activities_id { get; set; }

        public virtual List<tbl_Activity> package_Activities { get; set; }

    }
}