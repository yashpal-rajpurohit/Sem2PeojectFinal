﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2.Models
{
    public class UserLogin : IValidatableObject
    {
        [Required]
        public string user_email { get; set; }
        [DataType(DataType.Password)]
        [Required]
        public string user_password { get; set; }
        public bool RememberMe { get; set; }

        TheTourEntities1 tourLogin = new TheTourEntities1();
        ValidationResult vr;
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            bool IsValidUser = tourLogin.tbl_user
                              .Any(u => u.user_email.ToLower() == this.user_email.ToLower() && u
                              .user_password == this.user_password);

            if (IsValidUser)
            {
                vr = ValidationResult.Success;
            }
            else
            {
                vr = new ValidationResult("Invalid Username or Password");
            }
            return new List<ValidationResult>() { vr };
        }
    }
}