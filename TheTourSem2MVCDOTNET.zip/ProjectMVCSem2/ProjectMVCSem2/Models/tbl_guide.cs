﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2
{
    public class tbl_guideValidation
    {
        [Required(ErrorMessage ="Guide Name cannot be blank")]
        public string guide_name { get; set; }

        [Required(ErrorMessage = "Contact Number cannot be blank")]

        [RegularExpression(@"[0-9]{10}",ErrorMessage ="Enter only 10 digit mobile Number")]
        public string guide_contact { get; set; }
        
        [Required(ErrorMessage ="Guide Fees cannot be blank")]
        [DataType(DataType.Currency)]
        public decimal guide_fees { get; set; }



    }
    [MetadataType(typeof(tbl_guideValidation))]
    public partial class tbl_guide
    {

    }
}
