﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2
{
    public partial class tbl_ActivityValidation
    {
        public int activity_id { get; set; }
        [Required(ErrorMessage = "Activity Name is required")]
        public string activity_name { get; set; }


        [Required(ErrorMessage = "Activity Timing is required")]
        //[RegularExpression(@"/d/d/:/d/d/:/d/d", ErrorMessage = "Please enter Timing in HH:MM:SS format")]
        [DataType(DataType.Time)]
        public System.TimeSpan activity_timing { get; set; }
        
        [Required(ErrorMessage = "Activity Cost is required")]
        public decimal activity_cost { get; set; }
        public int activity_type { get; set; }
        public System.DateTime createDate { get; set; }
        public System.DateTime updateDate { get; set; }
        
    }
    [MetadataType(typeof(tbl_ActivityValidation))]
    // Note the partial keyword
    public partial class tbl_Activity { }
}