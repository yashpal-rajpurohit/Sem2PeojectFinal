﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2
{
    public partial class tbl_cityValidation
    {
        [Required(ErrorMessage ="City Name cannot be Blank")]
        public string city_name { get; set; }

    }

    [MetadataType(typeof(tbl_cityValidation))]
    // Note the partial keyword
    public partial class tbl_city { }
}