﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2
{
    public partial class tbl_stateValidation
    {
        public int state_id { get; set; }
        [Required(ErrorMessage ="State Name cannot be blanked")]
        public string state_name { get; set; }
        public System.DateTime createDate { get; set; }
        public System.DateTime updateDate { get; set; }

    }
    [MetadataType(typeof(tbl_stateValidation))]
    // Note the partial keyword
    public partial class tbl_state { }
}
