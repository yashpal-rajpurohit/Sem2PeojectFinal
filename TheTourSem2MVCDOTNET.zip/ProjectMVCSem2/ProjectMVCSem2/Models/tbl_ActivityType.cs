﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectMVCSem2
{
    public class tbl_activityTypeValidation
    {
        [Required(ErrorMessage ="ActivityType cannot be blank")]
        public string activityType_name { get; set; }

    }

    [MetadataType(typeof(tbl_activityTypeValidation))]
    public partial class tbl_activityType { }
}